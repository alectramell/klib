# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('karmon')

from karmon_lib import Window
from karmon.AboutKarmonDialog import AboutKarmonDialog
from karmon.PreferencesKarmonDialog import PreferencesKarmonDialog

# See karmon_lib.Window.py for more details about how this class works
class KarmonWindow(Window):
    __gtype_name__ = "KarmonWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(KarmonWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutKarmonDialog
        self.PreferencesDialog = PreferencesKarmonDialog

        # Code for other initialization actions should be added here.

        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.updatebutton = self.builder.get_object('updatebutton')
        self.upgradebutton = self.builder.get_object('upgradebutton')
        self.termbutton = self.builder.get_object('termbutton')
        self.musicbutton = self.builder.get_object('musicbutton')
        self.skypebutton = self.builder.get_object('skypebutton')

        username = getpass.getuser()
        username = str(username)

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('/usr/share/karmon/media/klib/index.html')
        self.webview.open(home)

        os.system('clear')

    def on_updatebutton_clicked(self, widget):
        username = getpass.getuser()
        username = str(username)
        home = str('file:///home/' + username + '/klib/index.html')
        self.webview.open(home)
        os.system('gnome-terminal --title="Karmon v1.0 | Ghost Terminal.." -x sh -c "clear && python ~/klib/activate" &')

    def on_upgradebutton_clicked(self, widget):
        os.system('ASK=$(zenity --question --title="Update Karmon..") && gnome-terminal --title="Login to help karmon learn.." -x sh -c "cd ~/ && sudo rm -r ~/klib && git clone https://github.com/alectramell/klib.git && sudo dpkg -i ~/klib/karmon_0.1_all.deb"')

    def on_termbutton_clicked(self, widget):
        os.system('clear')
        os.system('cd ~/ && gnome-terminal --title="Karmon v1.0 | Terminal.." &')

    def on_musicbutton_clicked(self, widget):
        os.system('clear')
        os.system('rhythmbox &')  

    def on_skypebutton_clicked(self, widget):
        os.system('clear')
        os.system('skype &')  

    def on_exitbutton_clicked(self, widget):
        exit()

